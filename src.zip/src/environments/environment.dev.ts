export const environment = {
  production: true,
  APP_URL: '',
  IMAGE_URL: '',
  fbAppId: '',
  fbAppSecret: '',
  redirectUri: '',
  apiEndPoint: ''
};
