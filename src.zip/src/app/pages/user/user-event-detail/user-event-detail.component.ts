import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-event-detail',
  templateUrl: './user-event-detail.component.html',
  styleUrls: ['./user-event-detail.component.scss']
})
export class UserEventDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
