import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-faqs',
  templateUrl: './edit-faqs.component.html',
  styleUrls: ['./edit-faqs.component.scss']
})
export class EditFaqsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
