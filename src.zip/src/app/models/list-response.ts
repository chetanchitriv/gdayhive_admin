export class ListResponse<T> {
    public data: T[];
    public totalRecords: number;
}
