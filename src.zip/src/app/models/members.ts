export class Members {
    id: number;
    fullName: string;
    userName: string;
    createdAt: string;
    createdBy: number;
    LastLoggingDate: string;
    status: number;
    sectorId: any;
    sectorName: any;
    
}
